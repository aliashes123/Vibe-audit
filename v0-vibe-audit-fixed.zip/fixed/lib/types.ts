export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface Finding {
  id: string;
  module: string;
  title: string;
  severity: Severity;
  confidence: number;
  evidence: string;
  remediation: string[];
  score_delta: number;
}

export interface AuditResult {
  repo: string;
  owner: string;
  score: number;
  grade: string;
  timestamp: string;
  findings: Finding[];
  summary: {
    critical: number;
    high: number;
    medium: number;
    low: number;
    info: number;
  };
}

export interface RepoInfo {
  name: string;
  full_name: string;
  description: string | null;
  stargazers_count: number;
  forks_count: number;
  open_issues_count: number;
  default_branch: string;
  visibility: string;
  language: string | null;
}
