"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import BrandLogo from "@/components/BrandLogo"

export default function LandingPage() {
  const router = useRouter()
  const [repoUrl, setRepoUrl] = useState("")
  const [token, setToken] = useState("")
  const [showToken, setShowToken] = useState(false)
  const [tokenVisible, setTokenVisible] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [stage, setStage] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    if (!repoUrl.trim()) {
      setError("Please paste a GitHub repository URL.")
      return
    }
    setIsLoading(true)
    setStage("Connecting to GitHub")

    const t1 = setTimeout(() => setStage("Inspecting repository"), 800)
    const t2 = setTimeout(() => setStage("Scanning API routes"), 2000)
    const t3 = setTimeout(() => setStage("Checking secrets & dependencies"), 3400)
    const t4 = setTimeout(() => setStage("Scoring findings"), 4800)

    try {
      const response = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          repo_url: repoUrl.trim(),
          token: token.trim() || undefined,
        }),
      })

      ;[t1, t2, t3, t4].forEach(clearTimeout)

      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || "Failed to audit repository")
      }

      // Clear token from memory once the request is done
      setToken("")
      // Store full audit in sessionStorage to avoid URL length limits
      sessionStorage.setItem("latest_audit", JSON.stringify(data.audit))
      router.push(data.redirect)
    } catch (err) {
      ;[t1, t2, t3, t4].forEach(clearTimeout)
      setError(err instanceof Error ? err.message : "An error occurred")
      setIsLoading(false)
      setStage("")
    }
  }

  return (
    <main className="min-h-screen bg-background relative overflow-hidden">
      {/* Brand-gradient ambient glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute -top-40 left-1/4 w-[600px] h-[600px] rounded-full blur-[140px] opacity-20"
             style={{ background: "radial-gradient(circle, #b16cea 0%, transparent 70%)" }} />
        <div className="absolute top-40 right-0 w-[500px] h-[500px] rounded-full blur-[140px] opacity-15"
             style={{ background: "radial-gradient(circle, #ff5e69 0%, transparent 70%)" }} />
        <div className="absolute top-1/3 left-0 w-[450px] h-[450px] rounded-full blur-[140px] opacity-15"
             style={{ background: "radial-gradient(circle, #186FE1 0%, transparent 70%)" }} />
      </div>

      {/* Header */}
      <header className="relative z-20 flex items-center justify-between px-4 sm:px-8 py-5 max-w-7xl mx-auto">
        <BrandLogo size="md" />
        <nav className="flex items-center gap-2 sm:gap-4">
          <a
            href="https://brandilite.com#pricing"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex text-sm font-medium text-muted hover:text-foreground transition-colors px-3 py-2"
          >
            Pricing
          </a>
          <a
            href="https://brandilite.com"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex text-sm font-medium text-muted hover:text-foreground transition-colors px-3 py-2"
          >
            Brandilite
          </a>
          <a
            href="https://cal.com/brandilite/15min"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary hover:bg-primary-hover text-primary-foreground text-sm font-semibold rounded-lg transition-colors"
          >
            Hire a Dev
          </a>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative z-10 flex flex-col items-center justify-center px-4 pt-10 sm:pt-16 pb-16 text-center max-w-4xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-card border border-border rounded-full mb-6">
          <span className="w-2 h-2 bg-brand-crimson rounded-full animate-pulse" />
          <span className="text-xs font-semibold text-muted uppercase tracking-wider">100% Free · No Signup</span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold mb-6 leading-[1.05] text-balance">
          <span className="text-foreground">Your repo&apos;s </span>
          <span className="font-serif italic brand-gradient-text">security score</span>
          <br />
          <span className="text-foreground">in </span>
          <span className="brand-gradient-text">60 seconds</span>
          <span className="text-foreground">.</span>
        </h1>

        <p className="text-muted text-lg sm:text-xl mb-10 max-w-2xl mx-auto leading-relaxed text-pretty">
          Paste any GitHub repo — public or private. We&apos;ll scan for exposed API routes,
          committed secrets, missing auth, and supply-chain risks. Then we&apos;ll show you exactly how to fix each one.
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto">
          <div className="flex flex-col sm:flex-row gap-3 p-2 bg-card border border-border rounded-2xl focus-within:border-brand-blue/60 focus-within:ring-4 focus-within:ring-brand-blue/15 transition-all">
            <div className="flex items-center gap-3 flex-1 px-3 sm:px-4">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" className="text-muted flex-shrink-0">
                <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.4 3-.405 1.02.005 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
              </svg>
              <input
                type="text"
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                placeholder="github.com/owner/repo"
                className="w-full py-3 bg-transparent text-foreground placeholder-muted-2 focus:outline-none text-base"
                disabled={isLoading}
                aria-label="GitHub repository URL"
              />
            </div>
            <button
              type="submit"
              disabled={isLoading || !repoUrl.trim()}
              className="px-6 sm:px-8 py-3 bg-primary hover:bg-primary-hover disabled:opacity-50 disabled:cursor-not-allowed text-primary-foreground font-semibold rounded-xl transition-colors active:scale-[0.98] whitespace-nowrap"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Scanning
                </span>
              ) : (
                "Run audit"
              )}
            </button>
          </div>

          {/* Connect private repo toggle */}
          <div className="mt-3 flex items-center justify-center">
            <button
              type="button"
              onClick={() => setShowToken((v) => !v)}
              className="inline-flex items-center gap-2 text-sm text-muted hover:text-foreground transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                      stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
              {showToken ? "Hide private-repo connector" : "Scanning a private repo? Connect with GitHub"}
            </button>
          </div>

          {/* Token input */}
          {showToken && (
            <div className="mt-4 p-4 sm:p-5 rounded-2xl bg-card border border-border text-left">
              <label htmlFor="pat" className="block text-sm font-semibold text-foreground mb-1.5">
                GitHub Personal Access Token
              </label>
              <p className="text-xs text-muted mb-3 leading-relaxed">
                Paste a <span className="text-foreground font-medium">classic</span> or <span className="text-foreground font-medium">fine-grained</span> token with read access to the repo (scope:{" "}
                <code className="px-1.5 py-0.5 rounded bg-background text-foreground text-[11px] font-mono border border-border">repo</code>).{" "}
                <a
                  href="https://github.com/settings/tokens/new?scopes=repo&description=Brandilite%20Repo%20Auditor"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-brand-blue hover:underline font-medium"
                >
                  Create one →
                </a>
              </p>
              <div className="relative">
                <input
                  id="pat"
                  type={tokenVisible ? "text" : "password"}
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  autoComplete="off"
                  spellCheck={false}
                  disabled={isLoading}
                  className="w-full h-11 pl-3 pr-16 rounded-lg bg-background border border-border focus:border-brand-blue focus:outline-none focus:ring-2 focus:ring-brand-blue/30 text-foreground placeholder-muted-2 text-sm font-mono"
                />
                <button
                  type="button"
                  onClick={() => setTokenVisible((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-1 text-xs text-muted hover:text-foreground rounded"
                  aria-label="Toggle token visibility"
                >
                  {tokenVisible ? "Hide" : "Show"}
                </button>
              </div>
              <div className="mt-3 flex items-start gap-2 text-[11px] text-muted-2 leading-relaxed">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" className="mt-0.5 shrink-0 text-brand-blue" aria-hidden="true">
                  <path d="M12 2l7 4v6c0 4.5-3 8.5-7 10-4-1.5-7-5.5-7-10V6l7-4z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>
                  Used once for this scan. Never stored. Never logged. You can revoke it any time at{" "}
                  <a href="https://github.com/settings/tokens" target="_blank" rel="noopener noreferrer" className="underline hover:text-foreground">
                    github.com/settings/tokens
                  </a>
                  .
                </span>
              </div>
            </div>
          )}

          {/* Status */}
          {isLoading && stage && (
            <div className="mt-4 text-sm text-muted flex items-center justify-center gap-2" role="status">
              <span className="h-2 w-2 rounded-full bg-brand-blue animate-pulse" />
              {stage}…
            </div>
          )}

          {error && (
            <div role="alert" className="mt-4 p-3 rounded-lg bg-destructive/10 border border-destructive/40 text-sm text-left">
              <span className="text-brand-crimson font-medium">{error}</span>
            </div>
          )}

          {/* Example chips */}
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-xs">
            <span className="text-muted-2">Try:</span>
            {["vercel/next.js", "shadcn/ui", "facebook/react"].map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setRepoUrl(ex)}
                className="px-2.5 py-1 rounded-md bg-card border border-border hover:border-brand-blue hover:text-foreground text-muted transition-colors"
              >
                {ex}
              </button>
            ))}
          </div>
        </form>

        {/* Trust badge */}
        <div className="mt-10 inline-flex items-center gap-3 rounded-full border border-border bg-card/70 backdrop-blur px-4 py-2.5 max-w-xl">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-brand-blue shrink-0" aria-hidden="true">
            <path d="M12 2l7 4v6c0 4.5-3 8.5-7 10-4-1.5-7-5.5-7-10V6l7-4z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="text-xs sm:text-sm text-muted text-left">
            <strong className="text-foreground">We keep your data safe.</strong>{" "}
            No source code, audit reports, or tokens are stored, logged, or shared with anyone.
          </span>
        </div>
      </section>

      {/* What we check */}
      <section className="relative z-10 max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <p className="text-xs font-bold uppercase tracking-widest brand-gradient-text mb-3">What we check</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-foreground text-balance">
            12+ security checks. <span className="font-serif italic text-muted">Zero setup.</span>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { title: "Exposed API Routes", desc: "Unauthenticated routes, open CORS, leaky endpoints — caught before attackers find them.", color: "var(--brand-crimson)", icon: "api" },
            { title: "Secret Scanning", desc: "Hardcoded API keys, tokens, RSA keys, and .env files committed to git.", color: "var(--brand-orange)", icon: "key" },
            { title: "Dependency Audit", desc: "Outdated packages and known CVEs in your lockfile.", color: "var(--brand-purple)", icon: "package" },
            { title: "Branch Protection", desc: "Required reviews, status checks, and force-push blocks.", color: "var(--brand-blue)", icon: "branch" },
            { title: "CI/CD Security", desc: "Unpinned GitHub Actions, over-permissioned workflows.", color: "var(--brand-purple)", icon: "workflow" },
            { title: "Compliance Checks", desc: "SECURITY.md, LICENSE, CODEOWNERS, and disclosure policy.", color: "var(--brand-blue)", icon: "shield" },
          ].map((feature) => (
            <div
              key={feature.title}
              className="p-6 bg-card border border-border rounded-2xl hover:border-border-strong hover:bg-card-elevated transition-all group"
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                style={{ background: `${feature.color}1f`, color: feature.color }}
              >
                <FeatureIcon name={feature.icon} />
              </div>
              <h3 className="text-foreground font-bold text-lg mb-2">{feature.title}</h3>
              <p className="text-muted text-sm leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA banner */}
      <section className="relative z-10 max-w-6xl mx-auto px-4 py-16">
        <div className="relative overflow-hidden rounded-3xl brand-gradient p-[1.5px]">
          <div className="rounded-3xl bg-background p-8 sm:p-12 text-center relative overflow-hidden">
            <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-30"
                 style={{ background: "radial-gradient(circle, #b16cea 0%, transparent 70%)" }} />
            <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-20"
                 style={{ background: "radial-gradient(circle, #ff8a56 0%, transparent 70%)" }} />
            <div className="relative">
              <p className="font-serif italic brand-gradient-text text-lg mb-3">Already found issues?</p>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-foreground mb-4 leading-tight text-balance">
                We&apos;ll <span className="brand-gradient-text">fix every one</span>.
              </h2>
              <p className="text-muted text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
                Brandilite pairs you with a Fortune-500 engineer who&apos;ll fix every finding in this report —
                secrets, auth, CI, the lot — and hand back a clean repo. Most fixes ship the same week.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <a
                  href="https://cal.com/brandilite/15min"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-primary hover:bg-primary-hover text-primary-foreground font-semibold rounded-xl transition-colors"
                >
                  Book a 15-min call
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M5 12h14m-7-7l7 7-7 7" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </a>
                <a
                  href="https://brandilite.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-card border border-border hover:border-border-strong text-foreground font-medium rounded-xl transition-colors"
                >
                  Visit Brandilite
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M7 17L17 7M17 7H7M17 7V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border mt-8">
        <div className="max-w-6xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandLogo size="sm" />
            <span className="text-sm text-muted-2">© 2026 Brandilite</span>
          </div>
          <div className="flex items-center gap-5 text-sm">
            <Link href="https://brandilite.com" target="_blank" className="text-muted hover:text-foreground transition-colors">
              brandilite.com
            </Link>
            <Link href="https://brandilite.com#pricing" target="_blank" className="text-muted hover:text-foreground transition-colors">
              Pricing
            </Link>
            <Link href="https://cal.com/brandilite/15min" target="_blank" className="text-brand-blue font-semibold hover:underline">
              Hire a Dev
            </Link>
          </div>
        </div>
      </footer>
    </main>
  )
}

function FeatureIcon({ name }: { name: string }) {
  const props = { width: 20, height: 20, viewBox: "0 0 24 24", fill: "none" }
  switch (name) {
    case "api":
      return (
        <svg {...props}>
          <path d="M10 14L21 3m0 0h-7m7 0v7M11 13H4a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    case "key":
      return (
        <svg {...props}>
          <path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )
    case "package":
      return (
        <svg {...props}>
          <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10m-8-14v10l8 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    case "branch":
      return (
        <svg {...props}>
          <circle cx="6" cy="6" r="2" stroke="currentColor" strokeWidth="2" />
          <circle cx="6" cy="18" r="2" stroke="currentColor" strokeWidth="2" />
          <circle cx="18" cy="6" r="2" stroke="currentColor" strokeWidth="2" />
          <path d="M6 8v8M8 6h6a4 4 0 014 4v0" stroke="currentColor" strokeWidth="2" />
        </svg>
      )
    case "workflow":
      return (
        <svg {...props}>
          <rect x="3" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2" />
          <rect x="14" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2" />
          <rect x="3" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2" />
          <rect x="14" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2" />
        </svg>
      )
    case "shield":
    default:
      return (
        <svg {...props}>
          <path d="M12 2L4 6v6c0 5 3.5 9.5 8 11 4.5-1.5 8-6 8-11V6l-8-4z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
  }
}
