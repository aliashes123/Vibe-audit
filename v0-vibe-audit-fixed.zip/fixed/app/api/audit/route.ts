import { NextRequest, NextResponse } from 'next/server';
import { Octokit } from '@octokit/rest';
import type { AuditResult, Finding, Severity } from '@/lib/types';

function parseRepoUrl(url: string): { owner: string; repo: string } | null {
  const patterns = [
    /github\.com\/([^/]+)\/([^/\s]+)/,
    /^([^/]+)\/([^/\s]+)$/,
  ];

  for (const pattern of patterns) {
    const match = url.trim().match(pattern);
    if (match) {
      return { owner: match[1], repo: match[2].replace(/\.git$/, '') };
    }
  }
  return null;
}

interface ApiRouteHit {
  path: string;
  filePath: string;
  hasAuth: boolean;
  hasCors: boolean;
  exportsAll: boolean;
}

interface RepoContext {
  hasSecurityMd: boolean;
  hasDependabot: boolean;
  hasCodeowners: boolean;
  hasWorkflows: boolean;
  hasLicense: boolean;
  hasEnvExample: boolean;
  hasGitignore: boolean;
  envInGitignore: boolean;
  workflowFiles: string[];
  unpinnedActions: number;
  apiRoutes: ApiRouteHit[];
  exposedRoutesCount: number;
  outdatedDeps: number;
  totalDeps: number;
  potentialSecrets: { file: string; pattern: string }[];
  defaultBranch: string;
  language: string | null;
  stars: number;
  isPrivate: boolean;
  size: number;
  framework: string | null;
}

async function getFileContent(
  octokit: Octokit,
  owner: string,
  repo: string,
  path: string
): Promise<string | null> {
  try {
    const { data } = await octokit.repos.getContent({ owner, repo, path });
    if ('content' in data && data.content) {
      return Buffer.from(data.content, 'base64').toString('utf-8');
    }
  } catch {
    return null;
  }
  return null;
}

async function fileExists(
  octokit: Octokit,
  owner: string,
  repo: string,
  paths: string[]
): Promise<boolean> {
  for (const path of paths) {
    try {
      await octokit.repos.getContent({ owner, repo, path });
      return true;
    } catch {
      // try next
    }
  }
  return false;
}

async function listFilesRecursive(
  octokit: Octokit,
  owner: string,
  repo: string,
  path: string,
  maxDepth = 3,
  currentDepth = 0
): Promise<{ path: string; type: string }[]> {
  if (currentDepth >= maxDepth) return [];
  const results: { path: string; type: string }[] = [];
  try {
    const { data } = await octokit.repos.getContent({ owner, repo, path });
    if (Array.isArray(data)) {
      for (const item of data) {
        results.push({ path: item.path, type: item.type });
        if (item.type === 'dir' && currentDepth < maxDepth - 1) {
          const nested = await listFilesRecursive(
            octokit,
            owner,
            repo,
            item.path,
            maxDepth,
            currentDepth + 1
          );
          results.push(...nested);
        }
      }
    }
  } catch {
    // ignore
  }
  return results;
}

async function scanApiRoutes(
  octokit: Octokit,
  owner: string,
  repo: string
): Promise<ApiRouteHit[]> {
  const hits: ApiRouteHit[] = [];

  // Next.js App Router: app/api/**/route.ts
  // Next.js Pages Router: pages/api/**/*.ts
  // Express style: any *.js with router.get/post
  const apiDirs = ['app/api', 'pages/api', 'src/app/api', 'src/pages/api'];

  for (const dir of apiDirs) {
    const files = await listFilesRecursive(octokit, owner, repo, dir, 4);
    for (const file of files) {
      if (file.type !== 'file') continue;
      if (!/\.(ts|tsx|js|jsx|mjs)$/.test(file.path)) continue;
      if (!/route\.(ts|tsx|js|jsx|mjs)$|api\/.+\.(ts|tsx|js|jsx|mjs)$/.test(file.path)) continue;

      const content = await getFileContent(octokit, owner, repo, file.path);
      if (!content) continue;

      // Convert file path to route path
      const routePath = file.path
        .replace(/^(src\/)?(app|pages)\/api/, '/api')
        .replace(/\/route\.(ts|tsx|js|jsx|mjs)$/, '')
        .replace(/\.(ts|tsx|js|jsx|mjs)$/, '')
        .replace(/\/index$/, '');

      const hasAuth =
        /auth|session|getServerSession|verifyToken|requireAuth|withAuth|isAuthenticated|jwt\.verify|getToken/i.test(
          content
        );
      const hasCors =
        /Access-Control-Allow-Origin.*['"]\*['"]/.test(content) ||
        /cors\(\s*\)/.test(content);
      const exportsAll =
        /export\s+(async\s+)?function\s+(GET|POST|PUT|DELETE|PATCH)/g.test(content);

      hits.push({
        path: routePath,
        filePath: file.path,
        hasAuth,
        hasCors,
        exportsAll,
      });
    }
  }

  return hits;
}

async function analyzeRepository(
  octokit: Octokit,
  owner: string,
  repo: string
): Promise<RepoContext> {
  const context: RepoContext = {
    hasSecurityMd: false,
    hasDependabot: false,
    hasCodeowners: false,
    hasWorkflows: false,
    hasLicense: false,
    hasEnvExample: false,
    hasGitignore: false,
    envInGitignore: false,
    workflowFiles: [],
    unpinnedActions: 0,
    apiRoutes: [],
    exposedRoutesCount: 0,
    outdatedDeps: 0,
    totalDeps: 0,
    potentialSecrets: [],
    defaultBranch: 'main',
    language: null,
    stars: 0,
    isPrivate: false,
    size: 0,
    framework: null,
  };

  try {
    const { data: repoData } = await octokit.repos.get({ owner, repo });
    context.defaultBranch = repoData.default_branch;
    context.language = repoData.language;
    context.stars = repoData.stargazers_count;
    context.isPrivate = repoData.private;
    context.size = repoData.size;
  } catch {
    // continue
  }

  // Parallel file existence checks
  const [
    hasSecurityMd,
    hasDependabot,
    hasCodeowners,
    hasLicense,
    hasEnvExample,
  ] = await Promise.all([
    fileExists(octokit, owner, repo, ['SECURITY.md', '.github/SECURITY.md', 'docs/SECURITY.md']),
    fileExists(octokit, owner, repo, ['.github/dependabot.yml', '.github/dependabot.yaml']),
    fileExists(octokit, owner, repo, ['CODEOWNERS', '.github/CODEOWNERS', 'docs/CODEOWNERS']),
    octokit.repos.getLicense({ owner, repo }).then(() => true).catch(() => false),
    fileExists(octokit, owner, repo, ['.env.example', '.env.sample', '.env.template']),
  ]);

  context.hasSecurityMd = hasSecurityMd;
  context.hasDependabot = hasDependabot;
  context.hasCodeowners = hasCodeowners;
  context.hasLicense = hasLicense;
  context.hasEnvExample = hasEnvExample;

  // .gitignore check
  const gitignore = await getFileContent(octokit, owner, repo, '.gitignore');
  if (gitignore) {
    context.hasGitignore = true;
    context.envInGitignore = /(^|\n)\.env(\.|\s|$|\*)/.test(gitignore);
  }

  // Workflows
  try {
    const { data: workflowsDir } = await octokit.repos.getContent({
      owner,
      repo,
      path: '.github/workflows',
    });
    if (Array.isArray(workflowsDir)) {
      context.hasWorkflows = true;
      context.workflowFiles = workflowsDir.map((f) => f.name);

      // Check first few workflows for unpinned actions
      for (const wf of workflowsDir.slice(0, 5)) {
        if (wf.type === 'file') {
          const content = await getFileContent(octokit, owner, repo, wf.path);
          if (content) {
            // Match `uses: owner/action@vN` (unpinned) vs `@<sha>` (pinned)
            const usesMatches = content.match(/uses:\s*[^\s]+@[^\s]+/g) || [];
            for (const u of usesMatches) {
              const ref = u.split('@')[1];
              if (ref && !/^[a-f0-9]{40}$/.test(ref)) {
                context.unpinnedActions++;
              }
            }
          }
        }
      }
    }
  } catch {
    // no workflows
  }

  // package.json scan for framework + deps
  const pkgJson = await getFileContent(octokit, owner, repo, 'package.json');
  if (pkgJson) {
    try {
      const pkg = JSON.parse(pkgJson);
      const allDeps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
      context.totalDeps = Object.keys(allDeps).length;

      if (allDeps.next) context.framework = 'Next.js';
      else if (allDeps.express) context.framework = 'Express';
      else if (allDeps.fastify) context.framework = 'Fastify';
      else if (allDeps['@nestjs/core']) context.framework = 'NestJS';
      else if (allDeps.koa) context.framework = 'Koa';
      else if (allDeps['@hapi/hapi']) context.framework = 'Hapi';

      // Heuristic: count deps with caret/tilde wildcards (potentially outdated)
      const wildcards = Object.values(allDeps).filter(
        (v) => typeof v === 'string' && /^[\^~]/.test(v)
      );
      context.outdatedDeps = Math.floor(wildcards.length * 0.3); // estimate
    } catch {
      // not valid JSON
    }
  }

  // Scan for exposed API routes (Next.js)
  if (context.framework === 'Next.js' || !context.framework) {
    const routes = await scanApiRoutes(octokit, owner, repo);
    context.apiRoutes = routes;
    context.exposedRoutesCount = routes.filter((r) => !r.hasAuth).length;
  }

  // Secret scanning heuristic - check common files for committed env values
  const filesToCheck = ['.env', '.env.local', '.env.production', 'config.json'];
  for (const file of filesToCheck) {
    const content = await getFileContent(octokit, owner, repo, file);
    if (content) {
      const patterns = [
        { name: 'AWS Access Key', regex: /AKIA[0-9A-Z]{16}/ },
        { name: 'GitHub Token', regex: /gh[pousr]_[A-Za-z0-9]{36,}/ },
        { name: 'OpenAI Key', regex: /sk-[A-Za-z0-9]{32,}/ },
        { name: 'Stripe Key', regex: /sk_(live|test)_[A-Za-z0-9]{24,}/ },
        { name: 'Generic API Key', regex: /(?:api[_-]?key|secret|password)["\s:=]+[A-Za-z0-9]{20,}/i },
      ];
      for (const p of patterns) {
        if (p.regex.test(content)) {
          context.potentialSecrets.push({ file, pattern: p.name });
        }
      }
    }
  }

  return context;
}

function generateFindings(owner: string, repo: string, context: RepoContext): Finding[] {
  const findings: Finding[] = [];

  // ===== EXPOSED API ROUTES (the user's requested feature) =====
  if (context.apiRoutes.length > 0) {
    const unauthRoutes = context.apiRoutes.filter((r) => !r.hasAuth);
    const corsRoutes = context.apiRoutes.filter((r) => r.hasCors);

    if (unauthRoutes.length > 0) {
      const sev: Severity = unauthRoutes.length >= 5 ? 'CRITICAL' : unauthRoutes.length >= 2 ? 'HIGH' : 'MEDIUM';
      const delta = unauthRoutes.length >= 5 ? -25 : unauthRoutes.length >= 2 ? -18 : -10;
      findings.push({
        id: 'API-001',
        module: 'exposed-api-routes',
        title: `${unauthRoutes.length} Unauthenticated API ${unauthRoutes.length === 1 ? 'Route' : 'Routes'} Detected`,
        severity: sev,
        confidence: 0.85,
        evidence: `Found ${unauthRoutes.length} API route(s) without authentication checks:\n${unauthRoutes
          .slice(0, 8)
          .map((r) => `  • ${r.path}  →  ${r.filePath}`)
          .join('\n')}${unauthRoutes.length > 8 ? `\n  ...and ${unauthRoutes.length - 8} more` : ''}`,
        remediation: [
          'Add authentication middleware (NextAuth, Clerk, Supabase Auth) to each route',
          'Verify requests with getServerSession() or similar before processing',
          'Return 401 for unauthenticated requests and 403 for unauthorized',
          'Consider rate-limiting public endpoints with Upstash Ratelimit or middleware',
        ],
        score_delta: delta,
      });
    } else {
      findings.push({
        id: 'API-001',
        module: 'exposed-api-routes',
        title: `All ${context.apiRoutes.length} API Routes Protected`,
        severity: 'INFO',
        confidence: 0.85,
        evidence: `Scanned ${context.apiRoutes.length} API route file(s) — all contain auth checks.`,
        remediation: [
          'Continue requiring auth on all routes by default',
          'Add E2E tests that verify 401 responses for unauthenticated requests',
          'Consider a deny-by-default middleware for new routes',
        ],
        score_delta: 0,
      });
    }

    if (corsRoutes.length > 0) {
      findings.push({
        id: 'API-002',
        module: 'cors-policy',
        title: `Wildcard CORS Detected on ${corsRoutes.length} ${corsRoutes.length === 1 ? 'Route' : 'Routes'}`,
        severity: 'HIGH',
        confidence: 0.8,
        evidence: `Found permissive CORS headers ("Access-Control-Allow-Origin: *") in:\n${corsRoutes
          .slice(0, 5)
          .map((r) => `  • ${r.filePath}`)
          .join('\n')}`,
        remediation: [
          'Replace wildcard "*" with an explicit allowlist of trusted origins',
          'Use environment variables to configure allowed origins per environment',
          'Never combine wildcard CORS with credentialed requests',
        ],
        score_delta: -12,
      });
    }
  } else if (context.framework === 'Next.js') {
    findings.push({
      id: 'API-001',
      module: 'exposed-api-routes',
      title: 'No API Routes Detected',
      severity: 'INFO',
      confidence: 0.6,
      evidence: 'No app/api or pages/api directories found — frontend-only or routes are in another location.',
      remediation: [
        'If using a separate backend, ensure CORS and auth are properly configured',
        'Document your API surface in a README or OpenAPI spec',
      ],
      score_delta: 0,
    });
  }

  // ===== SECRETS SCAN =====
  if (context.potentialSecrets.length > 0) {
    findings.push({
      id: 'SEC-100',
      module: 'secret-scanning',
      title: `${context.potentialSecrets.length} Potential ${context.potentialSecrets.length === 1 ? 'Secret' : 'Secrets'} Committed`,
      severity: 'CRITICAL',
      confidence: 0.9,
      evidence: `Detected potential leaked credentials:\n${context.potentialSecrets
        .map((s) => `  • ${s.pattern} in ${s.file}`)
        .join('\n')}`,
      remediation: [
        'Immediately rotate all exposed credentials',
        'Remove the secrets from git history with `git filter-repo` or BFG',
        'Move all secrets to environment variables (.env files)',
        'Add .env to .gitignore and use .env.example as a template',
      ],
      score_delta: -30,
    });
  } else {
    findings.push({
      id: 'SEC-100',
      module: 'secret-scanning',
      title: 'No Committed Secrets Found',
      severity: 'INFO',
      confidence: 0.75,
      evidence: 'Scanned common patterns (AWS, GitHub, OpenAI, Stripe) in env/config files — all clear.',
      remediation: [
        'Enable GitHub Secret Scanning Push Protection',
        'Use a pre-commit hook (gitleaks, trufflehog) for local detection',
      ],
      score_delta: 0,
    });
  }

  // ===== .env in .gitignore =====
  if (context.hasGitignore && !context.envInGitignore) {
    findings.push({
      id: 'GIT-001',
      module: 'git-hygiene',
      title: '.env Files Not in .gitignore',
      severity: 'HIGH',
      confidence: 0.95,
      evidence: '.gitignore exists but does not contain `.env` patterns. Environment files could be committed.',
      remediation: [
        'Add `.env`, `.env.local`, `.env.*.local` to .gitignore',
        'Run `git rm --cached .env` if any .env file is already tracked',
        'Commit a `.env.example` template instead',
      ],
      score_delta: -10,
    });
  }

  // ===== DEPENDENCIES =====
  if (context.totalDeps > 0) {
    if (context.outdatedDeps > 5) {
      findings.push({
        id: 'DEP-002',
        module: 'dependency-freshness',
        title: `~${context.outdatedDeps} Dependencies May Be Outdated`,
        severity: 'MEDIUM',
        confidence: 0.6,
        evidence: `Project has ${context.totalDeps} dependencies. Heuristic suggests ~${context.outdatedDeps} may be outdated.`,
        remediation: [
          'Run `npm outdated` or `pnpm outdated` to see current state',
          'Run `npm audit` to check for known CVEs',
          'Enable Dependabot for automated update PRs',
        ],
        score_delta: -6,
      });
    }
  }

  if (!context.hasDependabot) {
    findings.push({
      id: 'DEP-001',
      module: 'dependency-management',
      title: 'Dependabot Not Configured',
      severity: 'MEDIUM',
      confidence: 0.95,
      evidence: 'No .github/dependabot.yml configuration found.',
      remediation: [
        'Create .github/dependabot.yml with weekly update schedule',
        'Configure ecosystems (npm, pip, github-actions) you use',
        'Set appropriate reviewers and labels for dependency PRs',
      ],
      score_delta: -8,
    });
  } else {
    findings.push({
      id: 'DEP-001',
      module: 'dependency-management',
      title: 'Dependabot Enabled',
      severity: 'INFO',
      confidence: 1.0,
      evidence: 'Dependabot configuration found — automated dependency updates enabled.',
      remediation: [
        'Review Dependabot alerts regularly',
        'Consider auto-merge for patch-level updates',
      ],
      score_delta: 0,
    });
  }

  // ===== CI/CD =====
  if (context.hasWorkflows && context.unpinnedActions > 0) {
    findings.push({
      id: 'CI-001',
      module: 'ci-security',
      title: `${context.unpinnedActions} Unpinned GitHub Actions`,
      severity: 'MEDIUM',
      confidence: 0.85,
      evidence: `Found ${context.unpinnedActions} action(s) referenced by tag (e.g. @v3) instead of full commit SHA. Mutable refs can be hijacked.`,
      remediation: [
        'Pin actions to full 40-character commit SHAs',
        'Use Dependabot to automate SHA updates: `package-ecosystem: github-actions`',
        'Example: `uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4.1.1`',
      ],
      score_delta: -6,
    });
  } else if (context.hasWorkflows) {
    findings.push({
      id: 'CI-001',
      module: 'ci-security',
      title: 'GitHub Actions Workflows Found',
      severity: 'INFO',
      confidence: 0.9,
      evidence: `Detected ${context.workflowFiles.length} workflow file(s). No unpinned actions found.`,
      remediation: [
        'Add `permissions: read-all` at workflow level by default',
        'Grant write permissions only to specific jobs that need it',
      ],
      score_delta: 0,
    });
  }

  // ===== SECURITY POLICY =====
  if (!context.hasSecurityMd) {
    findings.push({
      id: 'SEC-001',
      module: 'security-policy',
      title: 'Missing SECURITY.md File',
      severity: 'MEDIUM',
      confidence: 1.0,
      evidence: 'No SECURITY.md found in root, .github/, or docs/ directories.',
      remediation: [
        'Create a SECURITY.md describing your disclosure process',
        'Include a security contact email or form',
        'Document supported versions and response SLAs',
      ],
      score_delta: -8,
    });
  } else {
    findings.push({
      id: 'SEC-001',
      module: 'security-policy',
      title: 'Security Policy Configured',
      severity: 'INFO',
      confidence: 1.0,
      evidence: 'SECURITY.md found — disclosure process documented.',
      remediation: ['Review the policy quarterly and keep contact info current'],
      score_delta: 0,
    });
  }

  // ===== BRANCH PROTECTION =====
  findings.push({
    id: 'BP-001',
    module: 'branch-protection',
    title: 'Branch Protection Status Unknown',
    severity: 'MEDIUM',
    confidence: 0.7,
    evidence: `Could not verify branch protection on "${context.defaultBranch}" (requires admin access).`,
    remediation: [
      'Go to Settings → Branches → Add branch protection rule',
      'Enable: Require pull request reviews (≥1 approval)',
      'Enable: Require status checks to pass before merging',
      'Enable: Do not allow bypassing the above settings',
    ],
    score_delta: -6,
  });

  // ===== CODEOWNERS =====
  if (!context.hasCodeowners) {
    findings.push({
      id: 'GOV-001',
      module: 'code-governance',
      title: 'No CODEOWNERS File',
      severity: 'LOW',
      confidence: 0.9,
      evidence: 'No CODEOWNERS file found in root or .github/ directory.',
      remediation: [
        'Add CODEOWNERS to assign reviewers automatically',
        'Cover critical paths: /app/api, /lib/auth, package.json',
        'Use team mentions (@org/team) for broader coverage',
      ],
      score_delta: -4,
    });
  }

  // ===== LICENSE =====
  if (!context.hasLicense && !context.isPrivate) {
    findings.push({
      id: 'LIC-001',
      module: 'compliance',
      title: 'No License File Detected',
      severity: 'LOW',
      confidence: 0.95,
      evidence: 'Public repository without a LICENSE file — usage terms are unclear.',
      remediation: [
        'Add a LICENSE file (MIT, Apache 2.0, or your choice)',
        'Use https://choosealicense.com to compare options',
      ],
      score_delta: -3,
    });
  }

  // ===== CODE SCANNING =====
  findings.push({
    id: 'SCAN-001',
    module: 'code-analysis',
    title: 'Enable Code Scanning',
    severity: 'LOW',
    confidence: 0.8,
    evidence: 'CodeQL scanning helps find vulnerabilities like SQL injection and XSS automatically.',
    remediation: [
      'Go to Security → Code scanning → Configure CodeQL',
      'Choose the default setup for most repos',
      'Review and address alerts in PRs',
    ],
    score_delta: -3,
  });

  return findings;
}

function calculateScore(findings: Finding[]): { score: number; grade: string } {
  let score = 100;
  for (const finding of findings) score += finding.score_delta;
  score = Math.max(0, Math.min(100, score));

  let grade: string;
  if (score >= 90) grade = 'A';
  else if (score >= 80) grade = 'B';
  else if (score >= 70) grade = 'C';
  else if (score >= 60) grade = 'D';
  else grade = 'F';

  return { score, grade };
}

function calculateSummary(findings: Finding[]): Record<Lowercase<Severity>, number> {
  return {
    critical: findings.filter((f) => f.severity === 'CRITICAL').length,
    high: findings.filter((f) => f.severity === 'HIGH').length,
    medium: findings.filter((f) => f.severity === 'MEDIUM').length,
    low: findings.filter((f) => f.severity === 'LOW').length,
    info: findings.filter((f) => f.severity === 'INFO').length,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { repo_url, token } = body as { repo_url?: string; token?: string };

    if (!repo_url) {
      return NextResponse.json({ error: 'Repository URL is required' }, { status: 400 });
    }

    const parsed = parseRepoUrl(repo_url);
    if (!parsed) {
      return NextResponse.json(
        { error: 'Invalid repository URL. Use github.com/owner/repo or owner/repo' },
        { status: 400 }
      );
    }

    const { owner, repo } = parsed;

    // Token precedence:
    //   1. User-supplied PAT in the request body (used once, never stored, never logged)
    //   2. Server-side GITHUB_TOKEN env var (optional, for higher rate limits on public repos)
    //   3. Anonymous (works for public repos within GitHub's IP rate limit)
    const userToken = token?.toString().trim() || undefined;
    const auth = userToken || process.env.GITHUB_TOKEN || undefined;
    const octokit = new Octokit({ auth, userAgent: 'brandilite-repo-auditor' });

    try {
      await octokit.repos.get({ owner, repo });
    } catch (e) {
      const err = e as { status?: number };
      if (err.status === 404) {
        return NextResponse.json(
          {
            error: userToken
              ? 'Repository not found, or this token does not have access. Make sure the token has the `repo` scope and you are a collaborator.'
              : 'Repository not found. If it is private, connect with a GitHub Personal Access Token (with the `repo` scope) to scan it.',
          },
          { status: 404 }
        );
      }
      if (err.status === 401 || err.status === 403) {
        return NextResponse.json(
          {
            error: userToken
              ? 'GitHub rejected the token. It may be expired, revoked, or missing the `repo` scope.'
              : 'GitHub returned an authorization error. Try connecting a Personal Access Token.',
          },
          { status: 403 }
        );
      }
      return NextResponse.json(
        { error: 'Unable to reach GitHub. Please try again in a moment.' },
        { status: 502 }
      );
    }

    // Check rate limit before proceeding
    try {
      const { data: rateLimit } = await octokit.rateLimit.get();
      if (rateLimit.rate.remaining < 10) {
        const resetTime = new Date(rateLimit.rate.reset * 1000).toLocaleTimeString();
        return NextResponse.json(
          { error: `GitHub API rate limit almost exhausted. Resets at ${resetTime}. Add a GITHUB_TOKEN to increase limits.` },
          { status: 429 }
        );
      }
    } catch {
      // ignore rate limit check failure, proceed anyway
    }

    const context = await analyzeRepository(octokit, owner, repo);
    const findings = generateFindings(owner, repo, context);
    const { score, grade } = calculateScore(findings);
    const summary = calculateSummary(findings);

    const audit: AuditResult = {
      repo,
      owner,
      score,
      grade,
      timestamp: new Date().toISOString(),
      findings,
      summary,
    };

    // Use a short slug (owner-repo) instead of base64 encoding the full audit
    // The full audit is returned in the response body and stored client-side
    const slug = `${owner}-${repo}`.toLowerCase().replace(/[^a-z0-9-]/g, '-');

    return NextResponse.json({
      redirect: `/audit/${slug}`,
      audit,
    });
  } catch (error) {
    console.error('[v0] Audit error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
