"use client"

import { useParams, useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import type { AuditResult } from "@/lib/types"
import { ScoreGauge } from "@/components/audit/ScoreGauge"
import { SeverityChart } from "@/components/audit/SeverityChart"
import { FindingCard } from "@/components/audit/FindingCard"
import BrandLogo from "@/components/BrandLogo"
import HireDevCTA from "@/components/HireDevCTA"

export default function AuditResultsPage() {
  const params = useParams()
  const router = useRouter()
  const [audit, setAudit] = useState<AuditResult | null>(null)
  const [error, setError] = useState("")
  const [filter, setFilter] = useState<string>("ALL")

  useEffect(() => {
    try {
      // First try sessionStorage (set by the form on the same session)
      const stored = sessionStorage.getItem("latest_audit")
      if (stored) {
        const parsed = JSON.parse(stored) as AuditResult
        setAudit(parsed)
        return
      }
      // If no sessionStorage (e.g. direct link), show a helpful error
      setError("Audit session expired. Please run a new audit.")
    } catch {
      setError("Invalid audit data")
    }
  }, [params.slug])

  const handlePrint = () => window.print()

  if (error) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 mx-auto mb-6 bg-destructive/10 rounded-full flex items-center justify-center">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" className="text-brand-crimson">
              <path d="M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
          <h1 className="text-2xl font-extrabold text-foreground mb-3">Audit not found</h1>
          <p className="text-muted mb-6">{error}</p>
          <button
            onClick={() => router.push("/")}
            className="px-6 py-3 bg-primary hover:bg-primary-hover text-primary-foreground font-semibold rounded-xl transition-colors"
          >
            Run a new audit
          </button>
        </div>
      </main>
    )
  }

  if (!audit) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex items-center gap-3 text-foreground">
          <svg className="animate-spin h-8 w-8 text-brand-blue" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          <span className="text-lg">Loading audit results…</span>
        </div>
      </main>
    )
  }

  const filteredFindings =
    filter === "ALL"
      ? audit.findings
      : audit.findings.filter((f) => f.severity === filter)

  const severityFilters = [
    { key: "ALL", label: "All", count: audit.findings.length, color: "#a0a3a8" },
    { key: "CRITICAL", label: "Critical", count: audit.summary.critical, color: "#ff5e69" },
    { key: "HIGH", label: "High", count: audit.summary.high, color: "#ff8a56" },
    { key: "MEDIUM", label: "Medium", count: audit.summary.medium, color: "#b16cea" },
    { key: "LOW", label: "Low", count: audit.summary.low, color: "#186FE1" },
    { key: "INFO", label: "Info", count: audit.summary.info, color: "#a0a3a8" },
  ]

  const urgentCount = audit.summary.critical + audit.summary.high

  return (
    <main className="min-h-screen bg-background pb-16 print:bg-white print:text-black">
      {/* Header */}
      <header className="border-b border-border bg-background/85 backdrop-blur-xl sticky top-0 z-50 print:static print:bg-white print:border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between gap-3">
          <BrandLogo size="md" />
          <div className="flex items-center gap-2">
            <a
              href="https://cal.com/brandilite/15min"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 bg-primary hover:bg-primary-hover text-primary-foreground font-semibold rounded-lg transition-colors print:hidden"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              Hire a Dev
            </a>
            <button
              onClick={handlePrint}
              className="p-2 sm:px-3 sm:py-2 bg-card border border-border text-foreground rounded-lg hover:bg-card-elevated transition-colors flex items-center gap-2 print:hidden"
              aria-label="Download as PDF"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2" />
                <rect x="6" y="14" width="12" height="8" />
              </svg>
              <span className="hidden sm:inline text-sm font-semibold">PDF</span>
            </button>
            <button
              onClick={() => router.push("/")}
              className="px-3 sm:px-4 py-2 bg-card border border-border text-foreground text-sm font-semibold rounded-lg hover:bg-card-elevated transition-colors print:hidden"
            >
              New Audit
            </button>
          </div>
        </div>
      </header>

      {/* Hero / Score Section */}
      <section className="border-b border-border print:border-gray-200 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
          <div
            className="absolute top-0 left-1/3 w-[500px] h-[500px] rounded-full blur-[120px] opacity-15"
            style={{ background: "radial-gradient(circle, #186FE1 0%, transparent 70%)" }}
          />
          <div
            className="absolute top-20 right-1/4 w-[400px] h-[400px] rounded-full blur-[120px] opacity-10"
            style={{ background: "radial-gradient(circle, #b16cea 0%, transparent 70%)" }}
          />
        </div>
        <div className="relative max-w-6xl mx-auto px-4 py-12 sm:py-16">
          <div className="grid lg:grid-cols-[auto_1fr] gap-12 items-center">
            <div className="flex justify-center">
              <ScoreGauge score={audit.score} grade={audit.grade} />
            </div>

            <div className="text-center lg:text-left">
              <div className="text-xs font-bold uppercase tracking-widest brand-gradient-text mb-3">
                Security Audit Report
              </div>
              <div className="flex items-center justify-center lg:justify-start gap-2 mb-3 flex-wrap">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" className="text-foreground print:text-black">
                  <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                </svg>
                <a
                  href={`https://github.com/${audit.owner}/${audit.repo}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-2xl sm:text-3xl font-extrabold text-foreground hover:text-brand-blue transition-colors print:text-black"
                >
                  {audit.owner}
                  <span className="text-muted-2">/</span>
                  {audit.repo}
                </a>
              </div>
              <p className="text-muted mb-6 text-sm">
                Audited{" "}
                {new Date(audit.timestamp).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>

              {/* Summary badges */}
              <div className="flex flex-wrap gap-2 justify-center lg:justify-start mb-6">
                {audit.summary.critical > 0 && (
                  <span className="px-3 py-1.5 rounded-lg text-sm font-bold" style={{ background: "#ff5e69", color: "#fff" }}>
                    {audit.summary.critical} Critical
                  </span>
                )}
                {audit.summary.high > 0 && (
                  <span className="px-3 py-1.5 rounded-lg text-sm font-bold" style={{ background: "#ff8a56", color: "#0d0e10" }}>
                    {audit.summary.high} High
                  </span>
                )}
                {audit.summary.medium > 0 && (
                  <span className="px-3 py-1.5 rounded-lg text-sm font-bold border" style={{ background: "rgba(177,108,234,0.15)", color: "#b16cea", borderColor: "rgba(177,108,234,0.35)" }}>
                    {audit.summary.medium} Medium
                  </span>
                )}
                {audit.summary.low > 0 && (
                  <span className="px-3 py-1.5 rounded-lg text-sm font-bold border" style={{ background: "rgba(24,111,225,0.15)", color: "#186FE1", borderColor: "rgba(24,111,225,0.35)" }}>
                    {audit.summary.low} Low
                  </span>
                )}
                {audit.summary.info > 0 && (
                  <span className="px-3 py-1.5 rounded-lg text-sm font-bold border bg-card text-muted border-border">
                    {audit.summary.info} Info
                  </span>
                )}
              </div>

              {/* Inline urgent CTA */}
              {urgentCount > 0 && (
                <div
                  className="inline-flex items-center gap-3 p-3 pl-4 rounded-xl border print:hidden"
                  style={{
                    background: "linear-gradient(90deg, rgba(255,94,105,0.10) 0%, rgba(255,138,86,0.10) 100%)",
                    borderColor: "rgba(255,94,105,0.30)",
                  }}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-brand-crimson flex-shrink-0" aria-hidden="true">
                    <path d="M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                  <span className="text-sm text-foreground">
                    <span className="font-bold">
                      {urgentCount} urgent {urgentCount === 1 ? "issue" : "issues"}
                    </span>{" "}
                    need attention
                  </span>
                  <a
                    href="https://cal.com/brandilite/15min"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-primary hover:bg-primary-hover text-primary-foreground text-sm font-bold rounded-lg transition-colors whitespace-nowrap"
                  >
                    Get them fixed
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Trust badge */}
          <div className="mt-10 max-w-3xl mx-auto lg:mx-0 inline-flex items-center gap-3 rounded-xl border border-border bg-card/70 px-4 py-3 print:hidden">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-brand-blue shrink-0" aria-hidden="true">
              <path d="M12 2l7 4v6c0 4.5-3 8.5-7 10-4-1.5-7-5.5-7-10V6l7-4z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="text-xs sm:text-sm text-muted leading-relaxed">
              <strong className="text-foreground">We keep your data safe.</strong>{" "}
              This report lives only in your browser URL. No source code, audit reports, or tokens are stored, logged, or shared with anyone — by us or any third party.
            </span>
          </div>
        </div>
      </section>

      {/* Charts Section */}
      <section className="py-12 border-b border-border print:border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl font-extrabold text-foreground mb-6 print:text-black">Analysis Overview</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <SeverityChart summary={audit.summary} />

            {/* Quick stats */}
            <div className="bg-card border border-border rounded-2xl p-6 print:bg-white print:border-gray-200">
              <h3 className="text-lg font-bold text-foreground mb-6 print:text-black">Quick Stats</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 bg-background border border-border rounded-xl print:bg-gray-50">
                  <div className="text-3xl font-extrabold text-foreground tabular-nums">{audit.findings.length}</div>
                  <div className="text-xs text-muted mt-1 uppercase tracking-wider font-semibold">Total Findings</div>
                </div>
                <div className="p-4 bg-background border border-border rounded-xl print:bg-gray-50">
                  <div className="text-3xl font-extrabold text-brand-crimson tabular-nums">{urgentCount}</div>
                  <div className="text-xs text-muted mt-1 uppercase tracking-wider font-semibold">Action Required</div>
                </div>
                <div className="p-4 bg-background border border-border rounded-xl print:bg-gray-50">
                  <div className="text-3xl font-extrabold text-brand-blue tabular-nums">{audit.score}</div>
                  <div className="text-xs text-muted mt-1 uppercase tracking-wider font-semibold">Security Score</div>
                </div>
                <div className="p-4 bg-background border border-border rounded-xl print:bg-gray-50">
                  <div className="text-3xl font-extrabold text-foreground print:text-black tabular-nums">{audit.grade}</div>
                  <div className="text-xs text-muted mt-1 uppercase tracking-wider font-semibold">Overall Grade</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Priority Actions */}
      {urgentCount > 0 && (
        <section className="py-12 border-b border-border print:border-gray-200">
          <div className="max-w-6xl mx-auto px-4">
            <div className="flex items-baseline justify-between mb-6 flex-wrap gap-2">
              <h2 className="text-2xl font-extrabold text-foreground print:text-black flex items-center gap-3">
                <span className="w-2.5 h-2.5 bg-brand-crimson rounded-full animate-pulse" />
                Priority Actions
              </h2>
              <span className="text-sm text-muted">
                {urgentCount} {urgentCount === 1 ? "issue" : "issues"} need immediate attention
              </span>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {audit.findings
                .filter((f) => f.severity === "CRITICAL" || f.severity === "HIGH")
                .map((finding) => {
                  const isCritical = finding.severity === "CRITICAL"
                  return (
                    <div
                      key={finding.id}
                      className="p-5 rounded-xl border transition-colors"
                      style={{
                        background: isCritical
                          ? "linear-gradient(135deg, rgba(255,94,105,0.10) 0%, var(--card) 100%)"
                          : "linear-gradient(135deg, rgba(255,138,86,0.10) 0%, var(--card) 100%)",
                        borderColor: isCritical ? "rgba(255,94,105,0.30)" : "rgba(255,138,86,0.30)",
                      }}
                    >
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <span
                          className="px-2 py-0.5 text-[10px] font-bold rounded uppercase tracking-wider"
                          style={{
                            background: isCritical ? "#ff5e69" : "#ff8a56",
                            color: isCritical ? "#fff" : "#0d0e10",
                          }}
                        >
                          {finding.severity}
                        </span>
                        <span className="text-[10px] font-mono text-muted-2">{finding.id}</span>
                      </div>
                      <h4 className="font-bold text-foreground mb-2 leading-snug">{finding.title}</h4>
                      <p className="text-sm text-muted line-clamp-2 leading-relaxed">{finding.remediation[0]}</p>
                    </div>
                  )
                })}
            </div>
          </div>
        </section>
      )}

      {/* Hire-a-Dev CTA */}
      <HireDevCTA criticalCount={audit.summary.critical} highCount={audit.summary.high} />

      {/* Findings */}
      <section className="py-12 border-t border-border print:border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-baseline justify-between mb-6 flex-wrap gap-3">
            <h2 className="text-2xl font-extrabold text-foreground print:text-black">Detailed Findings</h2>
            <span className="text-sm text-muted">
              Showing {filteredFindings.length} of {audit.findings.length}
            </span>
          </div>

          {/* Filter pills */}
          <div className="flex flex-wrap gap-2 mb-8 print:hidden">
            {severityFilters.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                disabled={f.count === 0 && f.key !== "ALL"}
                className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2 ${
                  filter === f.key
                    ? "bg-foreground text-background"
                    : "bg-card text-muted hover:bg-card-elevated hover:text-foreground border border-border disabled:opacity-40 disabled:cursor-not-allowed"
                }`}
              >
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: f.color }} />
                {f.label}
                <span className="text-xs text-muted-2">{f.count}</span>
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {filteredFindings.length === 0 ? (
              <div className="text-center py-12 text-muted">No findings match this filter.</div>
            ) : (
              filteredFindings.map((finding) => <FindingCard key={finding.id} finding={finding} />)
            )}
          </div>
        </div>
      </section>

      {/* Recommended GitHub features */}
      <section className="py-12 border-t border-border print:border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl font-extrabold text-foreground mb-2 print:text-black">Recommended GitHub Features</h2>
          <p className="text-muted mb-6">Free built-in security tools to strengthen your repository.</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: "Secret Scanning", desc: "Detect exposed API keys, tokens, and credentials.", href: "https://docs.github.com/en/code-security/secret-scanning", color: "#ff8a56" },
              { title: "Code Scanning", desc: "Find vulnerabilities with CodeQL static analysis.", href: "https://docs.github.com/en/code-security/code-scanning", color: "#b16cea" },
              { title: "Dependabot", desc: "Automate dependency and security updates.", href: "https://docs.github.com/en/code-security/dependabot", color: "#186FE1" },
              { title: "Branch Protection", desc: "Enforce reviews and required status checks.", href: "https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches", color: "#ff5e69" },
            ].map((item) => (
              <a
                key={item.title}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group p-5 bg-card border border-border rounded-2xl hover:border-border-strong hover:bg-card-elevated transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110"
                    style={{ background: `${item.color}1f`, color: item.color }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path d="M12 2L4 6v6c0 5 3.5 9.5 8 11 4.5-1.5 8-6 8-11V6l-8-4z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
                      <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="text-muted-2 group-hover:text-foreground transition-colors" aria-hidden="true">
                    <path d="M7 17L17 7M17 7H7M17 7V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
                <h4 className="font-bold text-foreground mb-1">{item.title}</h4>
                <p className="text-xs text-muted leading-relaxed">{item.desc}</p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border mt-8 print:hidden">
        <div className="max-w-6xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandLogo size="sm" />
            <span className="text-sm text-muted-2">© 2026 Brandilite</span>
          </div>
          <div className="flex items-center gap-5 text-sm">
            <a href="https://brandilite.com" target="_blank" rel="noopener noreferrer" className="text-muted hover:text-foreground transition-colors">
              brandilite.com
            </a>
            <a href="https://brandilite.com#pricing" target="_blank" rel="noopener noreferrer" className="text-muted hover:text-foreground transition-colors">
              Pricing
            </a>
            <a href="https://cal.com/brandilite/15min" target="_blank" rel="noopener noreferrer" className="text-brand-blue font-bold hover:underline">
              Hire a Dev
            </a>
          </div>
        </div>
      </footer>
    </main>
  )
}
