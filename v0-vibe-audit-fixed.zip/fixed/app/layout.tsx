import type { Metadata, Viewport } from 'next'
import { Figtree, Lora } from 'next/font/google'
import './globals.css'

const figtree = Figtree({ 
  subsets: ["latin"],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-figtree',
  display: 'swap',
});

const lora = Lora({
  subsets: ["latin"],
  style: ['italic'],
  variable: '--font-lora',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Brandilite Repo Auditor | Security Score in 60s',
  description: 'Instant GitHub repository security audits. Get your security score, find vulnerabilities, and actionable fixes in under 60 seconds. Hire a Brandilite dev to fix them.',
  generator: 'Brandilite',
}

export const viewport: Viewport = {
  themeColor: '#0d0e10',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className={`${figtree.variable} ${lora.variable} font-sans antialiased bg-background text-foreground`}>
        {children}
      </body>
    </html>
  )
}
