interface HireDevCTAProps {
  variant?: "primary" | "secondary" | "inline"
  criticalCount?: number
  highCount?: number
}

export default function HireDevCTA({
  variant = "primary",
  criticalCount = 0,
  highCount = 0,
}: HireDevCTAProps) {
  const totalUrgent = criticalCount + highCount

  if (variant === "inline") {
    return (
      <a
        href="https://cal.com/brandilite/15min"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-primary-hover text-primary-foreground font-semibold rounded-lg transition-colors print:hidden"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M13 10V3L4 14h7v7l9-11h-7z" fill="currentColor" />
        </svg>
        Hire a Dev to Fix
      </a>
    )
  }

  if (variant === "secondary") {
    return (
      <a
        href="https://brandilite.com"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 px-5 py-2.5 border border-border hover:border-border-strong text-foreground font-medium rounded-lg hover:bg-card-elevated transition-colors print:hidden"
      >
        Visit Brandilite
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M7 17L17 7M17 7H7M17 7V17"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </a>
    )
  }

  return (
    <section className="py-16 print:hidden">
      <div className="max-w-5xl mx-auto px-4">
        <div className="relative overflow-hidden rounded-3xl brand-gradient p-[1.5px]">
          <div className="relative overflow-hidden rounded-3xl bg-background p-8 sm:p-12">
            {/* Decorative glow */}
            <div
              className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-30"
              style={{ background: "radial-gradient(circle, #b16cea 0%, transparent 70%)" }}
            />
            <div
              className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-25"
              style={{ background: "radial-gradient(circle, #ff8a56 0%, transparent 70%)" }}
            />

            <div className="relative grid lg:grid-cols-[1.3fr_1fr] gap-8 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 brand-gradient text-white text-xs font-bold rounded-full mb-4 uppercase tracking-wide">
                  <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                  Now accepting new clients
                </div>

                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-foreground mb-4 leading-tight text-balance">
                  {totalUrgent > 0 ? (
                    <>
                      Need help fixing{" "}
                      <span className="font-serif italic brand-gradient-text">
                        {totalUrgent}
                      </span>{" "}
                      urgent {totalUrgent === 1 ? "issue" : "issues"}?
                    </>
                  ) : (
                    <>
                      Want a{" "}
                      <span className="font-serif italic brand-gradient-text">
                        Fortune-500
                      </span>{" "}
                      engineer on-call?
                    </>
                  )}
                </h2>

                <p className="text-base sm:text-lg text-muted mb-6 max-w-xl leading-relaxed">
                  Brandilite is a coding subscription for vibe coders. Fix bugs,
                  ship features, and stay secure with a 24-hour turnaround. Pause
                  or cancel anytime.
                </p>

                <div className="flex flex-wrap items-center gap-3">
                  <a
                    href="https://cal.com/brandilite/15min"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3.5 bg-primary hover:bg-primary-hover text-primary-foreground font-bold rounded-xl transition-colors active:scale-[0.98]"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <rect x="3" y="4" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="2" />
                      <path d="M16 2v4M8 2v4M3 10h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                    Book a 15-min call
                  </a>
                  <a
                    href="https://brandilite.com#pricing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3.5 bg-card border border-border hover:border-border-strong text-foreground font-semibold rounded-xl transition-colors"
                  >
                    See pricing
                  </a>
                </div>

                <div className="flex flex-wrap items-center gap-x-6 gap-y-2 mt-6 text-sm text-muted">
                  {["24h turnaround", "Any stack", "Pause anytime"].map((t) => (
                    <div key={t} className="flex items-center gap-1.5">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="#186FE1" aria-hidden="true">
                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                      </svg>
                      {t}
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing card preview */}
              <div className="relative">
                <div className="bg-card border border-border rounded-2xl p-6">
                  <div className="flex items-baseline justify-between mb-4">
                    <div>
                      <div className="text-xs uppercase tracking-wider brand-gradient-text font-bold mb-1">
                        Most Popular
                      </div>
                      <div className="text-foreground font-bold text-lg">
                        Pro Membership
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-extrabold text-foreground">
                        $999
                      </div>
                      <div className="text-xs text-muted">/ month</div>
                    </div>
                  </div>
                  <ul className="space-y-2.5 text-sm text-foreground/90">
                    {[
                      "30 requests / month",
                      "Bug fixes & feature coding",
                      "24-hour turnaround",
                      "Priority queue",
                      "Deployments handled",
                    ].map((item) => (
                      <li key={item} className="flex items-center gap-2">
                        <svg
                          width="14"
                          height="14"
                          viewBox="0 0 24 24"
                          fill="#186FE1"
                          className="flex-shrink-0"
                          aria-hidden="true"
                        >
                          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                        </svg>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
