"use client"

interface ScoreGaugeProps {
  score: number
  grade: string
}

export function ScoreGauge({ score, grade }: ScoreGaugeProps) {
  const radius = 120
  const strokeWidth = 14
  const normalizedRadius = radius - strokeWidth / 2
  const circumference = normalizedRadius * 2 * Math.PI
  const strokeDashoffset = circumference - (score / 100) * circumference

  // Brandilite palette only: blue (good) -> purple -> orange -> crimson (bad)
  const getScoreColor = (s: number) => {
    if (s >= 80) return "#186FE1" // Royal Blue
    if (s >= 60) return "#b16cea" // Purple
    if (s >= 40) return "#ff8a56" // Orange
    return "#ff5e69" // Crimson
  }

  const color = getScoreColor(score)

  return (
    <div className="relative flex items-center justify-center">
      <svg
        height={radius * 2}
        width={radius * 2}
        className="transform -rotate-90"
        aria-label={`Security score: ${score} out of 100, grade ${grade}`}
      >
        {/* Background ring */}
        <circle
          stroke="var(--border)"
          fill="transparent"
          strokeWidth={strokeWidth}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        {/* Glow */}
        <circle
          stroke={color}
          fill="transparent"
          strokeWidth={strokeWidth + 6}
          strokeDasharray={circumference + " " + circumference}
          style={{ strokeDashoffset }}
          strokeLinecap="round"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          className="opacity-20 blur-md"
        />
        {/* Progress */}
        <circle
          stroke={color}
          fill="transparent"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference + " " + circumference}
          style={{ strokeDashoffset, transition: "stroke-dashoffset 1.2s ease-out" }}
          strokeLinecap="round"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
      </svg>
      {/* Center label */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-6xl font-extrabold text-foreground print:text-black tabular-nums">{score}</span>
        <span className="text-sm text-muted mt-1 font-medium">/ 100</span>
        <span
          className="text-sm font-bold mt-3 px-3 py-1 rounded-full uppercase tracking-wider"
          style={{ color, backgroundColor: `${color}1f` }}
        >
          Grade {grade}
        </span>
      </div>
    </div>
  )
}
