"use client"

interface SeverityChartProps {
  summary: {
    critical: number
    high: number
    medium: number
    low: number
    info: number
  }
}

// Severity colors mapped directly to Brandilite swatches.
const severityConfig = [
  { key: "critical", label: "Critical", color: "#ff5e69", shortLabel: "C" }, // Crimson
  { key: "high", label: "High", color: "#ff8a56", shortLabel: "H" },         // Orange / Coral
  { key: "medium", label: "Medium", color: "#b16cea", shortLabel: "M" },     // Purple
  { key: "low", label: "Low", color: "#186FE1", shortLabel: "L" },           // Royal Blue
  { key: "info", label: "Info", color: "#a0a3a8", shortLabel: "I" },         // Grey
]

export function SeverityChart({ summary }: SeverityChartProps) {
  const maxValue = Math.max(
    summary.critical,
    summary.high,
    summary.medium,
    summary.low,
    summary.info,
    1,
  )

  const maxBarHeight = 160
  const total =
    summary.critical + summary.high + summary.medium + summary.low + summary.info

  return (
    <div className="bg-card border border-border rounded-2xl p-6 print:bg-white print:border-gray-200">
      <div className="flex items-baseline justify-between mb-6">
        <h3 className="text-lg font-bold text-foreground print:text-black">
          Severity Distribution
        </h3>
        <span className="text-xs text-muted-2 uppercase tracking-wider font-semibold">
          {total} total
        </span>
      </div>

      <div
        className="flex items-end justify-between gap-3 sm:gap-5"
        style={{ height: `${maxBarHeight + 60}px` }}
      >
        {severityConfig.map((sev) => {
          const value = summary[sev.key as keyof typeof summary]
          const barHeight =
            value > 0 ? Math.max((value / maxValue) * maxBarHeight, 24) : 6

          return (
            <div
              key={sev.key}
              className="flex flex-col items-center flex-1 group h-full justify-end"
            >
              {/* Count */}
              <span
                className="text-base sm:text-lg font-extrabold mb-2 tabular-nums transition-colors"
                style={{ color: value > 0 ? sev.color : "var(--muted-2)" }}
              >
                {value}
              </span>

              {/* Bar */}
              <div
                className="w-full max-w-12 rounded-t-lg relative overflow-hidden transition-all duration-700 ease-out"
                style={{
                  height: `${barHeight}px`,
                  backgroundColor: value > 0 ? sev.color : "var(--border)",
                  boxShadow: value > 0 ? `0 0 24px ${sev.color}30` : "none",
                }}
              >
                {value > 0 && (
                  <div className="absolute inset-0 bg-gradient-to-t from-transparent via-white/5 to-white/20" />
                )}
              </div>

              {/* Label */}
              <div className="mt-3 text-center">
                <span
                  className="text-xs font-bold block"
                  style={{ color: value > 0 ? sev.color : "var(--muted-2)" }}
                >
                  {sev.shortLabel}
                </span>
                <span className="text-[10px] text-muted-2 hidden sm:block mt-0.5">
                  {sev.label}
                </span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Legend bar */}
      {total > 0 && (
        <div className="mt-6 pt-4 border-t border-border print:border-gray-200">
          <div className="flex h-2 rounded-full overflow-hidden">
            {severityConfig.map((sev) => {
              const value = summary[sev.key as keyof typeof summary]
              if (value === 0) return null
              const width = (value / total) * 100
              return (
                <div
                  key={sev.key}
                  style={{ width: `${width}%`, backgroundColor: sev.color }}
                  title={`${sev.label}: ${value}`}
                />
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
