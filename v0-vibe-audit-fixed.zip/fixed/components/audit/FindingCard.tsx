"use client"

import type { Finding, Severity } from "@/lib/types"

interface FindingCardProps {
  finding: Finding
}

// All severity colors drawn from the Brandilite palette only.
const severityColors: Record<
  Severity,
  { hex: string; chipBg: string; chipText: string }
> = {
  CRITICAL: { hex: "#ff5e69", chipBg: "#ff5e69", chipText: "#ffffff" }, // Crimson
  HIGH:     { hex: "#ff8a56", chipBg: "#ff8a56", chipText: "#0d0e10" }, // Orange / Coral
  MEDIUM:   { hex: "#b16cea", chipBg: "#b16cea", chipText: "#ffffff" }, // Purple
  LOW:      { hex: "#186FE1", chipBg: "#186FE1", chipText: "#ffffff" }, // Royal Blue
  INFO:     { hex: "#a0a3a8", chipBg: "#a0a3a8", chipText: "#0d0e10" }, // Grey
}

export function FindingCard({ finding }: FindingCardProps) {
  const c = severityColors[finding.severity]

  return (
    <div
      className="bg-card border rounded-2xl p-6 transition-colors hover:bg-card-elevated print:bg-white print:border-gray-200"
      style={{ borderColor: `${c.hex}40` }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center flex-wrap gap-2 mb-2">
            <span
              className="px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider"
              style={{ background: c.chipBg, color: c.chipText }}
            >
              {finding.severity}
            </span>
            <span className="text-xs font-mono text-muted-2">{finding.id}</span>
            <span className="text-xs text-muted-2">·</span>
            <span className="text-xs text-muted">{finding.module}</span>
          </div>
          <h3 className="text-lg font-bold text-foreground print:text-black">
            {finding.title}
          </h3>
        </div>
        {finding.score_delta !== 0 && (
          <div
            className="text-base font-bold font-mono px-3 py-1 rounded-lg"
            style={{
              background:
                finding.score_delta < 0
                  ? "rgba(255, 94, 105, 0.12)"
                  : "rgba(24, 111, 225, 0.12)",
              color: finding.score_delta < 0 ? "#ff5e69" : "#186FE1",
            }}
          >
            {finding.score_delta > 0 ? "+" : ""}
            {finding.score_delta}
          </div>
        )}
      </div>

      {/* Evidence */}
      <div className="mb-4">
        <div className="text-[11px] text-muted-2 uppercase tracking-widest font-semibold mb-2">
          Evidence
        </div>
        <pre className="p-4 bg-background border border-border rounded-lg text-xs sm:text-sm text-foreground/90 overflow-x-auto font-mono leading-relaxed whitespace-pre-wrap print:bg-gray-50 print:text-gray-800 print:border-gray-200">
{finding.evidence}
        </pre>
      </div>

      {/* Remediation */}
      <div>
        <div className="text-[11px] text-muted-2 uppercase tracking-widest font-semibold mb-3">
          Remediation
        </div>
        <ol className="space-y-2.5">
          {finding.remediation.map((step, index) => (
            <li
              key={index}
              className="flex items-start gap-3 text-sm text-foreground/90 print:text-gray-700"
            >
              <span className="flex-shrink-0 w-6 h-6 rounded-md bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold print:bg-gray-200 print:text-black">
                {index + 1}
              </span>
              <span className="leading-relaxed pt-0.5">{step}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Footer */}
      <div className="mt-5 pt-4 border-t border-border flex items-center justify-between text-xs text-muted-2 print:border-gray-200">
        <span>
          Confidence:{" "}
          <span className="text-muted font-semibold">
            {Math.round(finding.confidence * 100)}%
          </span>
        </span>
        {finding.severity !== "INFO" && (
          <a
            href="https://cal.com/brandilite/15min"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-brand-blue hover:underline font-semibold print:hidden"
          >
            Hire a dev to fix
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
              <path
                d="M7 17L17 7M17 7H7M17 7V17"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </a>
        )}
      </div>
    </div>
  )
}
