import Link from 'next/link';

const LOGO_URL = 'https://cdn.prod.website-files.com/6912c26b361d7d4fc2afa09f/692cd3e64d9648112bbbda3f_Brandilite%20Logo%20(2)_imresizer.png';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  href?: string;
}

export default function BrandLogo({ size = 'md', href = '/' }: BrandLogoProps) {
  const sizes = {
    sm: { h: 28, w: 'h-7' },
    md: { h: 36, w: 'h-9' },
    lg: { h: 48, w: 'h-12' },
  };

  const sz = sizes[size];

  return (
    <Link href={href} className="inline-flex items-center gap-2 group">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={LOGO_URL}
        alt="Brandilite"
        height={sz.h}
        className={`${sz.w} w-auto object-contain`}
      />
    </Link>
  );
}
